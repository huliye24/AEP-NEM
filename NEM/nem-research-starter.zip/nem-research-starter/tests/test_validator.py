from pathlib import Path

from nem.validator import inspect_nem, validate_nem


def test_example_validates():
    path = Path(__file__).resolve().parents[1] / "examples" / "Moodify_Runtime_NEM_v0.1"
    result = validate_nem(path)
    assert result.ok, result.errors


def test_inspect_example():
    path = Path(__file__).resolve().parents[1] / "examples" / "Moodify_Runtime_NEM_v0.1"
    info = inspect_nem(path)
    assert info["nem_id"] == "MT-001"
    assert info["status"] == "BASIC"
    assert info["aep_count"] == 5
