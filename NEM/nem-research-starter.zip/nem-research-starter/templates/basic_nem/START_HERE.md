# START HERE

This folder is a NEM: Node Evolution Molecule.

Read in this order:

1. `nem_manifest.json`
2. `nem_spec.md`
3. `aep_map.yaml`
4. `validation/gate_criteria.md`
5. `aeps/`

Do not treat this folder as a random document collection. It is an evolvable node-module composed of AEP engineering atoms.
