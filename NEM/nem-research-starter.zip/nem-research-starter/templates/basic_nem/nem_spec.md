# NEM Spec

## 1. NEM Definition

This NEM represents a node evolution molecule: an evolvable engineering module composed of multiple AEP engineering atoms.

## 2. Purpose

Describe what engineering capability this NEM should create.

## 3. Boundaries

### This NEM does

- 

### This NEM does not

- 

## 4. Version Target

Current target:

```text
v0.1 BASIC
```

## 5. Upstream Dependencies

- 

## 6. Downstream Dependencies

- 

## 7. AEP Strategy

How many AEPs are required to reach BASIC, STABLE, EXTENDED, and ADOPTED?

## 8. Gate Criteria

See `validation/gate_criteria.md`.
