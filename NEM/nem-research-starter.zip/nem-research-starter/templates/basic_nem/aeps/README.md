# AEPs

Store AEP references or embedded AEP folders here.

Each AEP should represent one engineering atom that upgrades this NEM.
