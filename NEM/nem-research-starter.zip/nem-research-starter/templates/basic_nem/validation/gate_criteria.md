# NEM Gate Criteria

## BASIC Gate

A NEM can enter BASIC when:

- required AEPs are completed;
- each completed AEP has PoEW;
- outputs are stored under `reports/` or linked clearly;
- downstream interface is documented.

## STABLE Gate

A NEM can enter STABLE when:

- repeated execution succeeds;
- failure modes are known;
- dependency interface is clear;
- version upgrade decision is documented.

## ADOPTED Gate

A NEM can enter ADOPTED when:

- another NEM can depend on it;
- core evidence is reproducible;
- unresolved risks are documented;
- the module can be used in a main engineering chain.
