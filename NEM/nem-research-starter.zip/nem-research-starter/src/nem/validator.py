from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

REQUIRED_FILES = [
    "START_HERE.md",
    "nem_manifest.json",
    "nem_spec.md",
    "aep_map.yaml",
    "changelog.md",
]

REQUIRED_DIRS = [
    "aeps",
    "validation",
    "reports",
]

ALLOWED_NEM_STATUSES = {
    "DRAFT",
    "BASIC",
    "STABLE",
    "EXTENDED",
    "ADOPTED",
    "REFACTORED",
    "DEPRECATED",
    "ARCHIVED",
}

@dataclass
class ValidationResult:
    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    manifest: dict[str, Any] = field(default_factory=dict)

    def print(self) -> None:
        if self.ok:
            print("NEM validation: PASS")
        else:
            print("NEM validation: FAIL")
        for error in self.errors:
            print(f"ERROR: {error}")
        for warning in self.warnings:
            print(f"WARNING: {warning}")


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_yaml(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return data or {}


def validate_nem(path: str | Path) -> ValidationResult:
    root = Path(path)
    errors: list[str] = []
    warnings: list[str] = []
    manifest: dict[str, Any] = {}

    if not root.exists():
        return ValidationResult(ok=False, errors=[f"Path does not exist: {root}"])
    if not root.is_dir():
        return ValidationResult(ok=False, errors=[f"Path is not a directory: {root}"])

    for rel in REQUIRED_FILES:
        if not (root / rel).is_file():
            errors.append(f"Missing required file: {rel}")

    for rel in REQUIRED_DIRS:
        if not (root / rel).is_dir():
            errors.append(f"Missing required directory: {rel}")

    manifest_path = root / "nem_manifest.json"
    if manifest_path.exists():
        try:
            manifest = load_json(manifest_path)
        except json.JSONDecodeError as exc:
            errors.append(f"Invalid JSON in nem_manifest.json: {exc}")

    if manifest:
        for key in ["format", "format_version", "nem_id", "nem_name", "status", "version"]:
            if key not in manifest:
                errors.append(f"nem_manifest.json missing key: {key}")
        if manifest.get("format") != "NEM":
            errors.append("nem_manifest.json field 'format' must be 'NEM'")
        status = manifest.get("status")
        if status and status not in ALLOWED_NEM_STATUSES:
            errors.append(f"Invalid NEM status: {status}")

    aep_map_path = root / "aep_map.yaml"
    if aep_map_path.exists():
        try:
            aep_map = load_yaml(aep_map_path)
            aeps = aep_map.get("aeps", [])
            if not isinstance(aeps, list):
                errors.append("aep_map.yaml field 'aeps' must be a list")
            if isinstance(aeps, list) and len(aeps) == 0:
                warnings.append("aep_map.yaml contains no AEP entries")
            for i, aep in enumerate(aeps):
                if not isinstance(aep, dict):
                    errors.append(f"AEP entry #{i} must be an object")
                    continue
                for key in ["id", "name", "status"]:
                    if key not in aep:
                        errors.append(f"AEP entry #{i} missing key: {key}")
        except yaml.YAMLError as exc:
            errors.append(f"Invalid YAML in aep_map.yaml: {exc}")

    validation_dir = root / "validation"
    if validation_dir.exists() and not (validation_dir / "gate_criteria.md").exists():
        warnings.append("validation/gate_criteria.md is recommended")

    return ValidationResult(ok=len(errors) == 0, errors=errors, warnings=warnings, manifest=manifest)


def inspect_nem(path: str | Path) -> dict[str, Any]:
    root = Path(path)
    manifest_path = root / "nem_manifest.json"
    aep_map_path = root / "aep_map.yaml"

    manifest = load_json(manifest_path) if manifest_path.exists() else {}
    aep_map = load_yaml(aep_map_path) if aep_map_path.exists() else {}
    aeps = aep_map.get("aeps", []) if isinstance(aep_map, dict) else []

    return {
        "path": str(root),
        "nem_id": manifest.get("nem_id"),
        "nem_name": manifest.get("nem_name"),
        "version": manifest.get("version"),
        "status": manifest.get("status"),
        "aep_count": len(aeps) if isinstance(aeps, list) else 0,
        "upstream_nems": manifest.get("upstream_nems", []),
        "downstream_nems": manifest.get("downstream_nems", []),
    }
