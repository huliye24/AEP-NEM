from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from .validator import inspect_nem, validate_nem


def cmd_validate(args: argparse.Namespace) -> int:
    result = validate_nem(args.path)
    result.print()
    return 0 if result.ok else 1


def cmd_inspect(args: argparse.Namespace) -> int:
    info = inspect_nem(args.path)
    if args.json:
        print(json.dumps(info, ensure_ascii=False, indent=2))
    else:
        print(f"NEM ID:        {info.get('nem_id')}")
        print(f"NEM Name:      {info.get('nem_name')}")
        print(f"Version:       {info.get('version')}")
        print(f"Status:        {info.get('status')}")
        print(f"AEP Count:     {info.get('aep_count')}")
        print(f"Path:          {info.get('path')}")
    return 0


def cmd_init(args: argparse.Namespace) -> int:
    target = Path(args.target)
    if target.exists() and any(target.iterdir()):
        print(f"Target exists and is not empty: {target}")
        return 1
    target.mkdir(parents=True, exist_ok=True)

    repo_root = Path(__file__).resolve().parents[2]
    template = repo_root / "templates" / "basic_nem"
    if template.exists():
        for item in template.iterdir():
            dest = target / item.name
            if item.is_dir():
                shutil.copytree(item, dest, dirs_exist_ok=True)
            else:
                shutil.copy2(item, dest)
    else:
        # Fallback minimal template when installed without repository files.
        (target / "aeps").mkdir(exist_ok=True)
        (target / "validation").mkdir(exist_ok=True)
        (target / "reports").mkdir(exist_ok=True)
        (target / "START_HERE.md").write_text("# START HERE\n", encoding="utf-8")
        (target / "nem_spec.md").write_text("# NEM Spec\n", encoding="utf-8")
        (target / "aep_map.yaml").write_text("aeps: []\n", encoding="utf-8")
        (target / "changelog.md").write_text("# Changelog\n", encoding="utf-8")

    manifest = {
        "format": "NEM",
        "format_version": "0.1",
        "nem_id": args.node_id,
        "nem_name": args.name,
        "version": "v0.1",
        "status": "DRAFT",
        "aep_count": 0,
        "upstream_nems": [],
        "downstream_nems": [],
    }
    (target / "nem_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"Created NEM scaffold: {target}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="nem", description="NEM research CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_validate = sub.add_parser("validate", help="Validate a NEM folder")
    p_validate.add_argument("path")
    p_validate.set_defaults(func=cmd_validate)

    p_inspect = sub.add_parser("inspect", help="Inspect a NEM folder")
    p_inspect.add_argument("path")
    p_inspect.add_argument("--json", action="store_true")
    p_inspect.set_defaults(func=cmd_inspect)

    p_init = sub.add_parser("init", help="Create a NEM scaffold")
    p_init.add_argument("target")
    p_init.add_argument("--node-id", default="NEM-001")
    p_init.add_argument("--name", default="Untitled NEM")
    p_init.set_defaults(func=cmd_init)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
