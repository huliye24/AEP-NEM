# NEM Research Starter

**NEM = Node Evolution Molecule / 节点进化分子**

NEM is a research project for defining the next layer above AEP in AI-native engineering.

- **AEP** is the engineering atom: the smallest portable, executable, verifiable work package.
- **NEM** is the engineering molecule: an evolvable node-module composed of multiple AEP atoms.
- **Track / Chain** is formed by multiple NEMs.
- **Project / Organism** is formed by multiple engineering chains.

This repository is an initial GitHub-ready scaffold for researching, documenting, validating, and prototyping NEM.

## Core Statement

> AEP is the engineering atom. NEM is the node evolution molecule.
>
> A NEM is not a static project node. It is an evolvable, versioned, upgradeable, refactorable engineering module composed of multiple AEPs.

## Repository Structure

```text
nem-research-starter/
├── README.md
├── docs/
│   ├── NEM_Node_Evolution_Molecule_v0.1.md
│   ├── NEM_Node_Evolution_Molecule_v0.1.pdf
│   ├── AEP_Standard_v0.1.md
│   └── AEP_Standard_v0.1.pdf
├── research/
│   ├── RESEARCH_ROADMAP.md
│   ├── questions/
│   └── notes/
├── src/nem/
│   ├── cli.py
│   ├── validator.py
│   └── __init__.py
├── schemas/
│   └── nem_manifest.schema.json
├── templates/basic_nem/
├── examples/Moodify_Runtime_NEM_v0.1/
├── tests/
├── .github/workflows/test.yml
├── pyproject.toml
├── LICENSE
└── CONTRIBUTING.md
```

## Quick Start

```bash
python -m venv .venv

# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS / Linux
source .venv/bin/activate

pip install -e .[dev]

nem inspect examples/Moodify_Runtime_NEM_v0.1
nem validate examples/Moodify_Runtime_NEM_v0.1
pytest
```

## Basic Commands

```bash
# Inspect a NEM folder
nem inspect examples/Moodify_Runtime_NEM_v0.1

# Validate a NEM folder
nem validate examples/Moodify_Runtime_NEM_v0.1

# Create a new NEM folder from template
nem init My_Runtime_NEM --node-id MT-001 --name "Runtime Cloud System"
```

## NEM Maturity Model

| Stage | Meaning | Typical AEP Count |
|---|---|---:|
| v0.1 BASIC | Basic usable molecule | 3-5 |
| v0.3 STABLE | Stable and repeatable | 8-12 |
| v0.5 EXTENDED | Extended capability | 12-18 |
| v1.0 ADOPTED | Accepted as a project dependency | 18-25 |
| v2.0 REFACTORED | Rebuilt or upgraded architecture | variable |

## License

MIT License.
