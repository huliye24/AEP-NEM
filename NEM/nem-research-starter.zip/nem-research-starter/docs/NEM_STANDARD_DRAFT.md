# NEM Standard Draft v0.1

This file is a working draft for formalizing NEM as a standard layer above AEP.

## Core Formula

```text
NEM = Σ(AEP_i × Validated_PoEW_i) + Gate + Version_State + Dependency_Interface
```

## Required NEM Properties

A NEM should be:

1. composable;
2. versioned;
3. upgradeable;
4. refactorable;
5. dependency-aware;
6. gate-validated;
7. portable as a research/engineering unit.

## Minimal NEM Folder

```text
NEM_NAME/
├── START_HERE.md
├── nem_manifest.json
├── nem_spec.md
├── aep_map.yaml
├── aeps/
├── validation/
├── reports/
└── changelog.md
```

## Version States

```text
DRAFT
BASIC
STABLE
EXTENDED
ADOPTED
REFACTORED
DEPRECATED
ARCHIVED
```
