# NEM Glossary

## AEP

**Atomic Engineering Package / AI Engineering Package**. The engineering atom: a portable, executable, verifiable work package.

## NEM

**Node Evolution Molecule**. The engineering molecule: an evolvable node module composed of multiple AEP atoms.

## PoEW

**Proof of Engineering Work**. A verifiable evidence set produced after executing AEPs or upgrading a NEM.

## Gate

A validation stage that determines whether a NEM version can move to BASIC, STABLE, EXTENDED, ADOPTED, or REFACTORED.

## Engineering Chain

A main track or side track formed by multiple dependent NEMs.

## Engineering Organism

A project-level system formed by multiple engineering chains.
