# START HERE — Moodify Runtime NEM

This example NEM models `MT-001 Runtime Cloud System` as a Node Evolution Molecule.

Purpose:

- show how a node is not a static task;
- show how multiple AEPs upgrade a node;
- show how a node moves from DRAFT to BASIC and then to STABLE.

Read order:

1. `nem_manifest.json`
2. `nem_spec.md`
3. `aep_map.yaml`
4. `validation/gate_criteria.md`
5. `reports/initial_gate_report.md`
