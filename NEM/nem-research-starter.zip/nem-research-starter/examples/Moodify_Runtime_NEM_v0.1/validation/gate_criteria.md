# Runtime NEM Gate Criteria

## BASIC Gate

Runtime NEM enters BASIC when:

- at least 5 AEPs are mapped;
- each BASIC AEP has PASS status;
- logs and summaries are produced;
- downstream NEM usage is documented;
- no P0 runtime failure remains unexplained.

## STABLE Gate

Runtime NEM enters STABLE when:

- failure classification exists;
- repeated failure does not cause infinite retry;
- resume behavior is defined;
- 6h and 24h runs are completed with reports.
