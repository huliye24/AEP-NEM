# Research Notes

Use this folder to store exploratory NEM notes.

Recommended filename format:

```text
YYYY-MM-DD_topic.md
```
