# Core Research Questions for NEM

1. What is the minimum unit of an engineering molecule?
2. How many AEPs should a NEM contain before it reaches BASIC maturity?
3. How should a NEM declare dependencies on other NEMs?
4. What evidence is required for a NEM version upgrade?
5. Can a NEM be partially adopted?
6. How should failed AEPs be represented inside a NEM?
7. How can NEM support both software tasks and non-software research tasks?
8. What is the difference between a NEM and a project module?
9. What should be human-readable, agent-readable, and machine-readable?
10. How should PoEW be stored and verified across multiple AEPs?
