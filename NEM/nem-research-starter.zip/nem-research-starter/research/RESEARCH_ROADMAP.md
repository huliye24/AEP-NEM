# NEM Research Roadmap

## Phase 0 — Concept Locking

- Lock NEM as Node Evolution Molecule.
- Define AEP as engineering atom.
- Define NEM as engineering molecule.
- Establish the AEP → NEM → Chain → Organism hierarchy.

## Phase 1 — Structural Standard

Research the minimum standard folder structure:

- `nem_manifest.json`
- `nem_spec.md`
- `aep_map.yaml`
- `validation/`
- `reports/`

## Phase 2 — Validation Model

Research how a NEM upgrades between versions:

- BASIC;
- STABLE;
- EXTENDED;
- ADOPTED;
- REFACTORED.

## Phase 3 — Tooling

Build minimal tools:

- `nem validate`
- `nem inspect`
- `nem init`
- `nem graph`
- `nem gate`

## Phase 4 — Real Case Studies

Use real projects as NEM examples:

- Moodify Runtime NEM;
- Moodify MRS Benchmark NEM;
- AEP Protocol Validator NEM;
- Sample Library NEM;
- Report System NEM.

## Phase 5 — Public Standard

Prepare:

- GitHub repository;
- public README;
- versioned standard documents;
- example NEM library;
- protocol paper.
