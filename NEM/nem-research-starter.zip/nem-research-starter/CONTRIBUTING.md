# Contributing to NEM Research

This project is currently in early protocol research.

Good contributions include:

- improving the NEM concept definition;
- refining the AEP → NEM relationship;
- designing better validation schemas;
- creating real NEM examples;
- improving the CLI validator;
- writing research notes on AI-native engineering units.

Please keep terms consistent:

- AEP = engineering atom;
- NEM = node evolution molecule;
- PoEW = proof of engineering work;
- Gate = version validation gate;
- Track / Chain = dependency line of NEMs.
