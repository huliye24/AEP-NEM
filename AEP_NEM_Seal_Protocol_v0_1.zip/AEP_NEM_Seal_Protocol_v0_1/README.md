# AEP-NEM Seal Protocol v0.1

**AEP 工业封口协议补丁包 / AEP Industrial Seal Protocol Pack**

This package is a drop-in extension for the `AEP-NEM` repository. It adds the missing closure layer between:

- `Function Complete`：功能已经做出来；
- `PoEW Evidence`：工程工作有证据；
- `Gate Pass`：质量门通过；
- `Seal Complete`：封口证据完整；
- `Industrial Done`：可以被下游长期依赖的工业级完成状态。

## Why this package exists

In AI-native engineering, a task can appear "done" after code runs once. But industrial engineering requires a stronger closure standard:

> **Done is not when the function exists. Done is when the result can be trusted, reproduced, audited, and safely depended on by the next node.**

## Package structure

```text
AEP_NEM_Seal_Protocol_v0_1/
├── README.md
├── specs/
│   ├── SEAL_PROTOCOL.md
│   └── INDUSTRIAL_DONE_SPEC.md
├── templates/
│   ├── SEAL_REPORT_TEMPLATE.md
│   └── SEAL_CHECKLIST_TEMPLATE.md
├── schemas/
│   └── seal_report.schema.json
├── examples/
│   ├── generic/
│   │   ├── SEAL_REPORT_EXAMPLE.md
│   │   └── seal_report_example.json
│   └── moodify/
│       └── AEP_SEAL_MOODIFY_EXAMPLE.md
├── governance/
│   └── SEAL_REVIEW_PROCESS.md
├── integration_patch/
│   ├── README_UPDATE_SNIPPET.md
│   └── GLOSSARY_UPDATE_SNIPPET.md
├── tools/
│   └── validate_seal_report.py
├── LICENSE_NOTE.md
├── CHANGELOG.md
└── PACKAGE_FILE_LIST.txt
```

## Recommended merge path

Copy these files into the root of the AEP-NEM repository:

```bash
cp -r specs templates schemas examples governance integration_patch tools /path/to/AEP-NEM/
```

Then update `README.md` and `docs/glossary.md` using the snippets in `integration_patch/`.

## Core status model

```text
DRAFT
→ IN_PROGRESS
→ FUNCTION_COMPLETE
→ EVIDENCE_PENDING
→ SEAL_REVIEW
→ SEAL_COMPLETE
→ INDUSTRIAL_DONE
```

Failure / correction path:

```text
SEAL_REVIEW
→ REOPEN_REQUIRED
→ REWORK_IN_PROGRESS
→ FUNCTION_COMPLETE
```

## Minimal standard

An AEP cannot be marked `Industrial Done` unless it has:

1. Functional output.
2. Complete PoEW record.
3. Passing Gate result.
4. Reproducible test evidence.
5. Artifact hashes or output references.
6. Regression / non-breaking evidence.
7. Known-risk statement.
8. Downstream dependency note.
9. Seal report.
10. Reviewer or automated verifier signature.

## Chinese summary

**功能完成不是完全完成。**

功能完成只说明“代码或任务做出来了”。  
封口完成说明“这个结果已经被证据、测试、日志、报告和质量门证明，可以被后续节点依赖”。  
工业级完成说明“这个 AEP 已经可以进入工程资产库，并成为 NEM/E-Chain 的可信组成部分”。
